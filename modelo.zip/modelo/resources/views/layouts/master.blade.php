<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="UTF-8">
        <title>{{ config('app.name', 'RCP') }}</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <link rel="shortcut icon" href="{{ url('/img/brtck.ico') }}" />
        <link rel="icon" href="{{ url('/img/brtck.ico') }}" type="image/x-icon">

        <link href="{{ asset('css/app.css') }}" rel="stylesheet">
        <link href="{{ asset('css/bootstrap-material-design.css') }}" rel="stylesheet">
        <link href="{{ asset('css/rcp.css') }}" rel="stylesheet">

        <style>
            .navbar-brand, .nav-link{
                color: black !important;
                font-size:14px !important;
            }
            #mail-message{
                padding-top: 12px; padding-right:14px; font-size:20px;  cursor:pointer;
            }
        </style>
    </head>
    <body>
        <!--Navbar-->
        <nav class="navbar navbar-expand-lg navbar-dark primary-color fixed-top">

            <!-- Navbar brand -->
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="navbar-brand" href="{{ url('/') }}">{{ config('app.name', 'RCP') }}</a>
                </li>
            </ul>

            <!-- Collapse button -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav" aria-controls="basicExampleNav"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Collapsible content -->
            <div class="collapse navbar-collapse" id="basicExampleNav">

                <!-- Links -->
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="{{ url('/') }}">Início
                        </a>
                    </li>
                    @if (Auth::check())
                        <li class="nav-item">
                            <a class="nav-link" href="{{ url('/querys') }}">Consultas</a>
                        </li>

                    @endif

                </ul>
                <!-- Links -->

                @if (Auth::check())
                    <ul class="navbar-nav ml-auto nav-flex-icons">

                        <li class="nav-item avatar dropdown show">
                            <a class="nav-link dropdown-toggle waves-effect waves-light" id="navbarDropdownMenuLink-5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                <img height="40px" src="{{ url('/img/gersin.jpg') }}" class="rounded-circle z-depth-0" alt="avatar image" id="exifviewer-img-1" exifid="-825876464" oldsrc="https://visaointuitiva.com/img/Photos/Avatars/avatar-2.jpg">
                                    
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-secondary hide" aria-labelledby="navbarDropdownMenuLink-5">
                                <a class="dropdown-item waves-effect waves-light" href="{{ route('logout') }}"
                                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Sair</a>
                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                    {{ csrf_field() }}
                                </form>
                            </div>
                        </li>
                    </ul>

                @else

                    <!-- Links -->
                    <ul class="navbar-nav ml-auto nav-flex-icons">
                        <form class="form-inline">
                            <div class="md-form my-0">
                                <input class="form-control mr-sm-2" type="text" placeholder="Buscar" aria-label="Search">
                            </div>
                        </form>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ url('/login') }}">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ url('/register') }}">Registrar</a>
                        </li>
                    </ul>
                    <!-- Links -->

                @endif

            </div>
            <!-- Collapsible content -->

        </nav>
        <!--/.Navbar-->
                                    

        @if (Auth::check())
            <br><br><br><br>
            <div class="container">

                @if (session('status'))
                    <div class="alert alert-success">
                        {{ session('status') }}
                    </div>
                @endif

                <div class="panel panel-default">

                        <div class="panel-heading">@yield('title')</div>
                        <div class="panel-body">
                            @yield('content')
                        </div>
                </div>
                <br><br><br>
            </div>
        @else
            <div class="container-fluid view">
                <h1>SER - Sistema de Edição de Relatório</h1>
                <p>Nossa aplicação foi densenvolvida com o objetivo de auxiliar nossos clientes a gerar relatórios dinâmicos e atraentes, sem que para isso, necessitem gastar horas e horas.</p>
                <p><a href="{{ url('/register') }}">Registre-se</a> agora para usufruir de todos os recursos disponibilizados para você.</p>
            </div>
        @endif


        <!--Footer-->
        <footer class="page-footer text-center font-small mt-4 wow fadeIn">
            <!--Copyright-->
            <div class="footer-copyright py-2">
                © 2018 Copyright:
                <a href="http://visaointuitiva.com/" target="_blank"> visaointuitiva.com </a> - SER - Sistema de Edição de Relatórios
            </div>
            <!--/.Copyright-->        
        </footer>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
        <script src="{{ asset('js/bootstrap-material-design.js') }}"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

    </body>
</html>
