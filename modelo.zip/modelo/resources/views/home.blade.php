@extends('layouts.master')

@section('title')
    Painel do Administrador
@stop

@section('content')
    <ul>
        <li>Consultas</li>
        <li>Relatórios</li>
    </ul>                        
@endsection

