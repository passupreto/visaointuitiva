@extends('../layouts/master')

@section('title')
   Nova consulta
@stop   

@section('content')

{{ HTML::ul($errors->all()) }}

{{ Form::open(array('url' => 'querys')) }}

    <div class="form-group">
        {{ Form::label('name', 'Nome') }}
        {{ Form::text('name',null, array('class' => 'form-control')) }}
    </div>

    <div class="form-group">
        {{ Form::label('description', 'Descrição') }}
        {{ Form::text('description',null, array('class' => 'form-control')) }}
    </div>

    {{ Form::submit('Inserir', array('class' => 'btn btn-primary')) }}

{{ Form::close() }}

@stop