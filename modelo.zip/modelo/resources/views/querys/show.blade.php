@extends('../layouts/master')

@section('title')
   Consulta: {{ $query->name }}
@stop   

@section('content')

    <h2>{{ $query->name }}</h2>
    <p>
        <strong>Nome:</strong> {{ $query->name }}<br>
        <strong>Descrição:</strong> {{ $query->description }}
    </p>

@stop