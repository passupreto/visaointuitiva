<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Query;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\View;
use Illuminate\Html\HtmlServiceProvider;
use Illuminate\Html\HtmlFacade;
use Session;

class QueryController extends Controller
{
 
    public function index()
    {
        $querys = Query::all();

        return View::make('querys.index')
            ->with('querys', $querys);
    }

    public function create()
    {
        return View::make('querys.create');
    }

    public function store()
    {
        // validate
        $rules = array(
            'description' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);

        // process
        if ($validator->fails()) {
            return Redirect::to('querys/create')
                ->withErrors($validator)
                ->withInput();
        } else {

            // store
            $query = new Query;
            $query->name = Input::get('name');
            $query->description = Input::get('description');
            $query->save();

            // redirect
            Session::flash('message', 'Consulta criada com sucesso!');
            return Redirect::to('querys');

        }
    }

    public function show($id)
    {
        $query = Query::find($id);

        return View::make('querys.show')
            ->with('query', $query);
    }

    public function edit($id)
    {
        $query = Query::find($id);

        return View::make('querys.edit')
            ->with('query', $query);
    }

    public function update($id)
    {
        // validate
        $rules = array(
            'description' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);

        // process
        if ($validator->fails()) {
            return Redirect::to('querys/' . $id . '/edit')
                ->withErrors($validator)
                ->withInput(Input::except('password'));
        } else {
        
            // store
            $query = Query::find($id);
            $query->description       = Input::get('description');
            $query->save();

            // redirect
            Session::flash('message', 'Consulta alterada com sucesso!');
            return Redirect::to('querys');
        }
    }    

    public function destroy($id)
    {
        // delete
        $query = Query::find($id);
        $query->delete();

        // redirect
        Session::flash('message', 'Consulta excluída com sucesso!');
        return Redirect::to('querys');
    }    
}
