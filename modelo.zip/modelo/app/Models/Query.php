<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Query extends Model
{

    protected $fillable = ['name','description'];
    protected $guarded = ['id', 'created_at', 'update_at'];
    protected $table = 'querys';    
    
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('querys', function (Blueprint $table) {

            $table->increments('id');
            $table->string('name',45);
            $table->text('description');
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('querys');
    }   

}