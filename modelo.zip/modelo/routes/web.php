<?php

Route::get('/', function () {
    return view('home');
});

Route::resource('querys', 'QueryController');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
