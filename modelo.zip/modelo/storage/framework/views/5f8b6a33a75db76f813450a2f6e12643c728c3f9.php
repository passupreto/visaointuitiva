<?php $__env->startSection('title'); ?>
    Consultas
    <a class="btn btn-small btn-info pull-right" href="<?php echo e(URL::to('querys/create')); ?>">Novo</a>
<?php $__env->stopSection(); ?>   

<?php $__env->startSection('content'); ?>

    <?php if(Session::has('message')): ?>
        <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
    <?php endif; ?>

    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <td>ID</td>
                <td>Nome</td>
                <td>Descrição</td>
                <td>Ações</td>
            </tr>
        </thead>
        <tbody>

        <?php $__currentLoopData = $querys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($value->id); ?></td>
                <td><?php echo e($value->name); ?></td>
                <td><?php echo e($value->description); ?></td>

                <td>

                    <!-- delete the query (uses the destroy method DESTROY /querys/{id} -->
                    <!-- we will add this later since its a little more complicated than the other two buttons -->
                    <?php echo e(Form::open(array('url' => 'querys/' . $value->id, 'class' => 'pull-right'))); ?>

                        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                        <?php echo e(Form::submit('Excluir', array('class' => 'btn btn-warning'))); ?>

                    <?php echo e(Form::close()); ?>


                    <a class="btn btn-small btn-success" href="<?php echo e(URL::to('querys/' . $value->id)); ?>">Ver</a>
                    <a class="btn btn-small btn-info" href="<?php echo e(URL::to('querys/' . $value->id . '/edit')); ?>">Alterar</a>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>