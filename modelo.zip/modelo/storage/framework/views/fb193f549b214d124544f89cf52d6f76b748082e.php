<?php $__env->startSection('title'); ?>
   Relatório: <?php echo e($report->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <ul>
      <li>ID: <?php echo e($report->id); ?></li>
      <li>Nome: <?php echo e($report->name); ?></li>
      <li>Categoria: <?php echo e($report->category); ?></li>
      <li>Ordem: <?php echo e($report->order); ?></li>
   </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>