<?php $__env->startSection('title'); ?>
   Nova Conexão
<?php $__env->stopSection(); ?>   

<?php $__env->startSection('content'); ?>

<?php echo e(HTML::ul($errors->all())); ?>


<?php echo e(Form::open(array('url' => 'connections'))); ?>


    <div class="form-group">
        <?php echo e(Form::label('name', 'Nome')); ?>

        <?php echo e(Form::text('name',null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('description', 'Descrição')); ?>

        <?php echo e(Form::text('description',null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('driver', 'Driver')); ?>

        <?php echo e(Form::text('driver',null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('servername', 'Servidor')); ?>

        <?php echo e(Form::text('servername',null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('dbname', 'Banco de Dados')); ?>

        <?php echo e(Form::text('dbname',null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('username', 'Usuário')); ?>

        <?php echo e(Form::text('username',null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('password', 'Senha')); ?>

        <?php echo e(Form::text('password',null, array('class' => 'form-control'))); ?>

    </div>

    <?php echo e(Form::submit('Inserir', array('class' => 'btn btn-primary'))); ?>


<?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>