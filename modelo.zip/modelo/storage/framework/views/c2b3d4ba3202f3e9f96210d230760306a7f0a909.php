<?php $__env->startSection('title'); ?>
   Serviço: <?php echo e($service->name); ?>

<?php $__env->stopSection(); ?>   

<?php $__env->startSection('content'); ?>

    <h2><?php echo e($service->name); ?></h2>
    <p>
        <strong>Nome:</strong> <?php echo e($service->name); ?><br>
        <strong>Descrição:</strong> <?php echo e($service->description); ?><br>
        <strong>Categoria:</strong> <?php echo e($service->category); ?><br>
        <strong>Propósito:</strong> <?php echo e($service->purpose); ?><br>
        <strong>Servidor:</strong> <?php echo e($service->hostname); ?><br>
        <strong>SSL Port:</strong> <?php echo e($service->sslport); ?><br>
        <strong>HTTP Port:</strong> <?php echo e($service->httpport); ?><br>
    </p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>