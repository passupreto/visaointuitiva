<?php $__env->startSection('title'); ?>
    Painel do Administrador
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <ul>
        <li>Consultas</li>
        <li>Relatórios</li>
    </ul>                        
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>