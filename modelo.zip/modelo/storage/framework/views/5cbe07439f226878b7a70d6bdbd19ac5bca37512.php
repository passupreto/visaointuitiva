<?php $__env->startSection('title'); ?>
   Consulta: <?php echo e($query->name); ?>

<?php $__env->stopSection(); ?>   

<?php $__env->startSection('content'); ?>

    <h2><?php echo e($query->name); ?></h2>
    <p>
        <strong>Nome:</strong> <?php echo e($query->name); ?><br>
        <strong>Descrição:</strong> <?php echo e($query->description); ?>

    </p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>