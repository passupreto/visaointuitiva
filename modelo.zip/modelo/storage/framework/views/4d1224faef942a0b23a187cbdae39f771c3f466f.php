<?php $__env->startSection('title'); ?>
   Conexão: <?php echo e($connection->name); ?>

<?php $__env->stopSection(); ?>   

<?php $__env->startSection('content'); ?>

    <h2><?php echo e($connection->name); ?></h2>
    <p>
        <strong>Nome:</strong> <?php echo e($connection->name); ?><br>
        <strong>Descrição:</strong> <?php echo e($connection->description); ?><br>
        <strong>Driver:</strong> <?php echo e($connection->driver); ?><br>
        <strong>Servidor:</strong> <?php echo e($connection->servername); ?><br>
        <strong>Banco de Dados:</strong> <?php echo e($connection->dbname); ?><br>
        <strong>Usuário:</strong> <?php echo e($connection->username); ?><br>
        <strong>Senha:</strong> <?php echo e($connection->password); ?><br>
    </p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>