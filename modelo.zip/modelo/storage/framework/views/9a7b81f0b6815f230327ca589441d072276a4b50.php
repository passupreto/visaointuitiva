<?php $__env->startSection('title'); ?>
   Relatórios
   <a class="btn btn-small btn-info pull-right" href="<?php echo e(URL::to('reports/create')); ?>">Novo</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php if(Session::has('message')): ?>
      <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
  <?php endif; ?>

  <table class="table table-striped table-bordered">

      <thead>
          <tr>
              <td>ID</td>
              <td>Nome</td>
              <td>Categoria</td>
              <td>Ordem</td>
              <td>Ações</td>
          </tr>
      </thead>
  
      <tbody>
      <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>

              <td><?php echo e($value->id); ?></td>
              <td><?php echo e($value->name); ?></td>
              <td><?php echo e($value->category); ?></td>
              <td><?php echo e($value->order); ?></td>

              <td>

                  <delete the nerd (uses the destroy method DESTROY /nerds/{id}>

                  <!-- show the report (uses the show method found at GET /reports/{id} -->
                  <a class="btn btn-small btn-success" href="<?php echo e(URL::to('reports/'.$value->id)); ?>">Ver</a>

                  <!-- edit this nerd (uses the edit method found at GET /nerds/{id}/edit -->
                  <a class="btn btn-small btn-info" href="<?php echo e(URL::to('reports/'.$value->id.'/edit')); ?>">Alterar</a>

              </td>
          </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
  </table>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('../layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>