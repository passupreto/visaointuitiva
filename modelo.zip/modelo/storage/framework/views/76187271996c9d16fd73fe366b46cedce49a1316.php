<?php $__env->startSection('title'); ?>
   Início
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <a target="_blank" class="btn btn-primary" href="https://fezvrasta.github.io/bootstrap-material-design/docs/4.0/material-design/buttons/">UI</a>

    <br>
    
    <button type="button" class="btn"><code>btn</code> only</button>
    <button type="button" class="btn active"><code>.active</code></button>

    <fieldset disabled>
        <button type="button" class="btn btn-secondary">Secondary</button>
        <button type="button" class="btn btn-success">Success</button>
    </fieldset>

    <button type="button" class="btn btn-raised btn-warning">Warning</button>
    <button type="button" class="btn btn-raised btn-danger">Danger</button>
    <button type="button" class="btn btn-raised btn-link">Link</button>
    <button type="button" class="btn btn-raised active"><code>.active</code></button>


    <button type="button" class="btn btn-raised btn-lg">Large button</button>
    <button type="button" class="btn btn-raised">Default button</button>
    <button type="button" class="btn btn-raised btn-sm">Small button</button>

    <h1>Floating action</h1>

    <button type="button" class="btn btn-primary bmd-btn-fab">
    <i class="material-icons">grade</i>
    </button>
    <button type="button" class="btn btn-secondary bmd-btn-fab">
    <i class="material-icons">grade</i>
    </button>
    <button type="button" class="btn btn-success bmd-btn-fab">
    <i class="material-icons">grade</i>
    </button>
    <button type="button" class="btn btn-info bmd-btn-fab">
    <i class="material-icons">grade</i>
    </button>
    <button type="button" class="btn btn-warning bmd-btn-fab">
    <i class="material-icons">grade</i>
    </button>
    <button type="button" class="btn btn-danger bmd-btn-fab">
    <i class="material-icons">grade</i>
    </button>
    <button type="button" class="btn btn-danger bmd-btn-fab active">
    <i class="material-icons">grade</i>
    </button>


    <fieldset disabled>
    <button type="button" class="btn btn-primary bmd-btn-fab">
        <i class="material-icons">grade</i>
    </button>
    <button type="button" class="btn btn-secondary bmd-btn-fab">
        <i class="material-icons">grade</i>
    </button>
    <button type="button" class="btn btn-success bmd-btn-fab">
        <i class="material-icons">grade</i>
    </button>
    <button type="button" class="btn btn-info bmd-btn-fab">
        <i class="material-icons">grade</i>
    </button>
    <button type="button" class="btn btn-warning bmd-btn-fab">
        <i class="material-icons">grade</i>
    </button>
    <button type="button" class="btn btn-danger bmd-btn-fab">
        <i class="material-icons">grade</i>
    </button>
    </fieldset>

    <h1>Tamanhos</h1>

<span class="btn-group-lg">
  <button type="button" class="btn btn-danger bmd-btn-fab">
    <i class="material-icons">grade</i>
  </button>
</span>
<button type="button" class="btn btn-danger bmd-btn-fab">
  <i class="material-icons">grade</i>
</button>
<button type="button" class="btn btn-danger bmd-btn-fab bmd-btn-fab-sm">
  <i class="material-icons">grade</i>
</button>
<span class="btn-group-sm">
  <button type="button" class="btn btn-danger bmd-btn-fab">
    <i class="material-icons">grade</i>
  </button>
</span>

    <h1>Tamanhos</h1>

<button type="button" class="btn btn-primary bmd-btn-icon">
  <i class="material-icons">more_vert</i>
</button>
<button type="button" class="btn btn-secondary bmd-btn-icon">
  <i class="material-icons">more_vert</i>
</button>
<button type="button" class="btn btn-success bmd-btn-icon">
  <i class="material-icons">more_vert</i>
</button>
<button type="button" class="btn btn-info bmd-btn-icon">
  <i class="material-icons">more_vert</i>
</button>
<button type="button" class="btn btn-warning bmd-btn-icon">
  <i class="material-icons">more_vert</i>
</button>
<button type="button" class="btn btn-danger bmd-btn-icon">
  <i class="material-icons">more_vert</i>
</button>
<button type="button" class="btn btn-danger bmd-btn-icon active">
  <i class="material-icons">more_vert</i>
</button>

    <h1>Tamanhos</h1>

<fieldset disabled>
  <button type="button" class="btn btn-primary bmd-btn-icon">
    <i class="material-icons">more_vert</i>
  </button>
  <button type="button" class="btn btn-secondary bmd-btn-icon">
    <i class="material-icons">more_vert</i>
  </button>
  <button type="button" class="btn btn-success bmd-btn-icon">
    <i class="material-icons">more_vert</i>
  </button>
  <button type="button" class="btn btn-info bmd-btn-icon">
    <i class="material-icons">more_vert</i>
  </button>
  <button type="button" class="btn btn-warning bmd-btn-icon">
    <i class="material-icons">more_vert</i>
  </button>
  <button type="button" class="btn btn-danger bmd-btn-icon">
    <i class="material-icons">more_vert</i>
  </button>
</fieldset>

    <h1>Tamanhos</h1>

<button type="button" class="btn bmd-btn-icon">
  <i class="material-icons">more_vert</i>
</button>
<button type="button" class="btn bmd-btn-icon bmd-btn-icon-sm">
  <i class="material-icons">more_vert</i>
</button>
<span class="btn-group-sm">
  <button type="button" class="btn bmd-btn-icon">
    <i class="material-icons">more_vert</i>
  </button>
</span>
    <h1>Tamanhos</h1>

    <h1>Tamanhos</h1>

    <h1>Tamanhos</h1>

    <h1>Tamanhos</h1>

    

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>