<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="UTF-8">
        <title><?php echo e(config('app.name', 'RCP')); ?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <link rel="shortcut icon" href="<?php echo e(url('/img/brtck.ico')); ?>" />
        <link rel="icon" href="<?php echo e(url('/img/brtck.ico')); ?>" type="image/x-icon">

        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/bootstrap-material-design.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/rcp.css')); ?>" rel="stylesheet">

        <style>
            .navbar-brand, .nav-link{
                color: black !important;
                font-size:14px !important;
            }
            #mail-message{
                padding-top: 12px; padding-right:14px; font-size:20px;  cursor:pointer;
            }
        </style>
    </head>
    <body>
        <!--Navbar-->
        <nav class="navbar navbar-expand-lg navbar-dark primary-color fixed-top">

            <!-- Navbar brand -->
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><?php echo e(config('app.name', 'RCP')); ?></a>
                </li>
            </ul>

            <!-- Collapse button -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav" aria-controls="basicExampleNav"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Collapsible content -->
            <div class="collapse navbar-collapse" id="basicExampleNav">

                <!-- Links -->
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>">Início
                            <span class="sr-only">(current)</span>
                        </a>
                    </li>
                    <?php if(Auth::check()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/reports')); ?>">Relatórios</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/services')); ?>">Serviços</a>
                        </li>

                        <!-- Dropdown -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Configurações</a>
                            <div class="dropdown-menu dropdown-primary" aria-labelledby="navbarDropdownMenuLink">
                                <a class="dropdown-item" href="<?php echo e(url('/connections')); ?>">Conexões</a>
                                <a class="dropdown-item" href="<?php echo e(url('/querys')); ?>">Consultas</a>
                            </div>
                        </li>
                    <?php endif; ?>

                </ul>
                <!-- Links -->

                <?php if(Auth::check()): ?>
                    <ul class="navbar-nav ml-auto nav-flex-icons">

                        <li class="nav-item">
                            <a id="mail-message" class="nav-link waves-effect waves-light"  >1 <i class="fa fa-envelope"></i></a>
                        </li>
                        <li class="nav-item avatar dropdown show">
                            <a class="nav-link dropdown-toggle waves-effect waves-light" id="navbarDropdownMenuLink-5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                <img height="40px" src="<?php echo e(url('/img/gersin.jpg')); ?>" class="rounded-circle z-depth-0" alt="avatar image" id="exifviewer-img-1" exifid="-825876464" oldsrc="https://visaointuitiva.com/img/Photos/Avatars/avatar-2.jpg">
                                    
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-secondary hide" aria-labelledby="navbarDropdownMenuLink-5">
                                <a class="dropdown-item waves-effect waves-light" href="#">Meu perfil</a>
                                <a class="dropdown-item waves-effect waves-light" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Sair</a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </div>
                        </li>
                    </ul>

                <?php else: ?>

                    <!-- Links -->
                    <ul class="navbar-nav ml-auto nav-flex-icons">
                        <form class="form-inline">
                            <div class="md-form my-0">
                                <input class="form-control mr-sm-2" type="text" placeholder="Buscar" aria-label="Search">
                            </div>
                        </form>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/login')); ?>">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/register')); ?>">Registrar</a>
                        </li>
                    </ul>
                    <!-- Links -->

                <?php endif; ?>

            </div>
            <!-- Collapsible content -->

        </nav>
        <!--/.Navbar-->
                                    

        <?php if(Auth::check()): ?>
            <br><br><br><br>
            <div class="container">

                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <div class="panel panel-default">

                        <div class="panel-heading"><?php echo $__env->yieldContent('title'); ?></div>
                        <div class="panel-body">
                            <?php echo $__env->yieldContent('content'); ?>
                        </div>
                </div>
                <br><br><br>
            </div>
        <?php else: ?>
            <div class="container-fluid view">
                <h1>SER - Sistema de Edição de Relatório</h1>
                <p>Nossa aplicação foi densenvolvida com o objetivo de auxiliar nossos clientes a gerar relatórios dinâmicos e atraentes, sem que para isso, necessitem gastar horas e horas.</p>
                <p><a href="<?php echo e(url('/register')); ?>">Registre-se</a> agora para usufruir de todos os recursos disponibilizados para você.</p>
            </div>
        <?php endif; ?>


        <!--Footer-->
        <footer class="page-footer text-center font-small mt-4 wow fadeIn">

            <!--Call to action-->
            <div class="pt-2">
                <a class="btn btn-outline-white" href="https://download.visaointuitiva.com/" target="_blank" role="button">Baixe o Sistema de Edição de Relatórios
                    <i class="fa fa-download ml-2"></i>
                </a>
                <a class="btn btn-outline-white" href="https://ead.visaointuitiva.com/" target="_blank" role="button">Inicie o tutorial gratúito do Sistema de Edição de Relatórios
                    <i class="fa fa-graduation-cap ml-2"></i>
                </a>
            </div>
            <!--/.Call to action-->

            <hr class="my-2">

            <!-- Social icons -->
            <div class="pb-2">
                <a href="https://www.facebook.com/gersonsilvaborges" target="_blank">
                    <i class="fa fa-facebook mr-3"></i>
                </a>

                <a href="https://twitter.com/borgesgerson" target="_blank">
                    <i class="fa fa-twitter mr-3"></i>
                </a>

                <a href="https://www.youtube.com/watch?v=0lNQ2udlNVQ" target="_blank">
                    <i class="fa fa-youtube mr-3"></i>
                </a>

                <a href="https://plus.google.com/106025868206048282956/posts/7fRbCyNruez" target="_blank">
                    <i class="fa fa-google-plus mr-3"></i>
                </a>

                <a href="https://dribbble.com/gersonborges" target="_blank">
                    <i class="fa fa-dribbble mr-3"></i>
                </a>

                <a href="https://br.pinterest.com/gersonsilvaborges/" target="_blank">
                    <i class="fa fa-pinterest mr-3"></i>
                </a>

                <a href="https://github.com/passupreto/visaointuitiva" target="_blank">
                    <i class="fa fa-github mr-3"></i>
                </a>

                <a href="https://codepen.io/gerson-borges/" target="_blank">
                    <i class="fa fa-codepen mr-3"></i>
                </a>
            </div>
            <!-- Social icons -->

            <!--Copyright-->
            <div class="footer-copyright py-2">
                © 2018 Copyright:
                <a href="http://visaointuitiva.com/" target="_blank"> visaointuitiva.com </a> - SER - Sistema de Edição de Relatórios
            </div>
            <!--/.Copyright-->        
        </footer>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
        <script src="<?php echo e(asset('js/bootstrap-material-design.js')); ?>"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

    </body>
</html>
