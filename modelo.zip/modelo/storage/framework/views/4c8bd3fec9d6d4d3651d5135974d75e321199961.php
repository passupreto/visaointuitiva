<?php $__env->startSection('title'); ?>
   Nova consulta
<?php $__env->stopSection(); ?>   

<?php $__env->startSection('content'); ?>

<?php echo e(HTML::ul($errors->all())); ?>


<?php echo e(Form::open(array('url' => 'querys'))); ?>


    <div class="form-group">
        <?php echo e(Form::label('name', 'Nome')); ?>

        <?php echo e(Form::text('name',null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('description', 'Descrição')); ?>

        <?php echo e(Form::text('description',null, array('class' => 'form-control'))); ?>

    </div>

    <?php echo e(Form::submit('Inserir', array('class' => 'btn btn-primary'))); ?>


<?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>